<?php
session_start();

include "modules/autoload.php";
include "includes/app.definitions.php";

?>