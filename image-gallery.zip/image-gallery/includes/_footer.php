<footer>
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p>
                        <b>This project has been made by three very talented students of VNTU university</b>
                        <br>
                        <b>As their project for Web Technologies subject</b>
                    </p>
                </div>
            </div>
        </footer>
 </div> <!-- /container -->


    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/myscript.js"></script>
  </body>
</html>